[-name-] Plugin
==================
TBD

Misc
----

This project uses [loguru](https://github.com/emilk/loguru) for logging (included under `src/cpp/logging`)

Licensing
---------
GPL version 3
