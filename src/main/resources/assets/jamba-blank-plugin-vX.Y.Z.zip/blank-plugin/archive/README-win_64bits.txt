Install instructions
====================

Windows (64 bit)
----------------
The directory structure in this archive matches the file system, so you can simply
copy it under C:\Program Files

Or if you prefer to install each file individually:

For VST2, copy VstPlugins\[-filename-].dll under
  - C:\Program Files\VstPlugins
  - or any DAW specific path (64bits)

For VST3, copy Common Files\VST3\[-filename-].vst3 under
  - C:\Program Files\Common Files\VST3 (may require admin access)
  - or any DAW specific path (64bits)

